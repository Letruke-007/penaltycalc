"""Tests for pipeline layer."""
