"""Tests for PDF extraction."""
