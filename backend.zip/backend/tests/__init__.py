"""
Test suite for PDF to XLSX conversion application.
"""
