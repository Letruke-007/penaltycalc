"""Tests for data normalization."""
