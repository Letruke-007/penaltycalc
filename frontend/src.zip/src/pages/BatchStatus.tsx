// frontend/src/pages/BatchStatus.tsx

import React, { useCallback } from "react";
import { ItemsTable } from "../components/ItemsTable";
import type { BatchId } from "../types";
import { useBatchStatus } from "../hooks/useBatchStatus";
import { batchService } from "../services/batchService";

export interface BatchStatusProps {
  batchId: BatchId;
}

export function BatchStatus(props: BatchStatusProps) {
  const { batchId } = props;
  const { state, actions } = useBatchStatus(batchId);

  // NOTE: batchService.downloadItemXlsx() already triggers browser download and returns void
  const onDownloadItemXlsx = useCallback(async (itemId: string) => {
    await batchService.downloadItemXlsx(itemId);
  }, []);

  const onDownloadMerged = useCallback(async () => {
    await batchService.downloadBatchXlsx(batchId);
  }, [batchId]);

  const b: any = state.batch; // keep optional fields without refactoring shared types

  const canDownloadMerged = Boolean(b && b.merge_status === "MERGED");
  const showMergeWarning = Boolean(b && b.merge_status === "SKIPPED" && b.merge_warning);
  const showMergeError = Boolean(b && b.merge_status === "ERROR" && b.merge_error);

  return (
    <div>
      <div style={{ marginBottom: 16, display: "flex", alignItems: "flex-end", gap: 10 }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>Статус пакета</div>
          <div style={{ fontSize: 13, color: "#525252" }}>
            Batch ID: <b>{batchId}</b>
          </div>
        </div>

        <div style={{ marginLeft: "auto", display: "flex", gap: 10 }}>
          <button
            type="button"
            onClick={() => void onDownloadMerged()}
            style={canDownloadMerged ? btnPrimaryStyle : btnDisabledStyle}
            disabled={!canDownloadMerged}
            title={
              canDownloadMerged
                ? "Скачать объединённый XLSX"
                : "Объединённый XLSX недоступен (merge не выполнен или отключён)"
            }
          >
            Скачать объединённый XLSX
          </button>

          <button type="button" onClick={() => void actions.reload()} style={btnSecondaryStyle}>
            Обновить
          </button>
        </div>
      </div>

      {state.error && (
        <div style={errorStyle}>
          <div style={{ fontWeight: 700, marginBottom: 4 }}>Ошибка получения статуса</div>
          <div style={{ fontSize: 13, whiteSpace: "pre-wrap" }}>{state.error}</div>
        </div>
      )}

      {b && (
        <>
          <div style={cardStyle}>
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <KV k="Состояние" v={humanBatchStatus(b.status)} />
              <KV k="Готово" v={`${state.progress.done} / ${state.progress.total}`} />
              <KV k="Ошибок" v={`${state.progress.errors}`} />
              <KV k="Создан" v={new Date(b.created_at).toLocaleString()} />
              {typeof b.merge_enabled === "boolean" && <KV k="Объединение" v={b.merge_enabled ? "Да" : "Нет"} />}
              {b.merge_status && <KV k="Merge" v={String(b.merge_status)} />}
            </div>
          </div>

          {showMergeWarning && (
            <div style={warningStyle}>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>Объединение не выполнено</div>
              <div style={{ fontSize: 13, whiteSpace: "pre-wrap" }}>{String(b.merge_warning)}</div>
              <div style={{ fontSize: 13, marginTop: 8, color: "#525252" }}>
                В этом режиме файл формируется отдельно по каждой справке.
              </div>
            </div>
          )}

          {showMergeError && (
            <div style={errorStyle}>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>Ошибка объединения</div>
              <div style={{ fontSize: 13, whiteSpace: "pre-wrap" }}>{String(b.merge_error)}</div>
            </div>
          )}

          {state.innMismatch.hasMismatch && (
            <div style={warningStyle}>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>Предупреждение</div>
              <div style={{ fontSize: 13 }}>
                В пакете обнаружены разные ИНН: {state.innMismatch.inns.join(", ")}. Проверьте, что справки относятся к одному должнику.
              </div>
            </div>
          )}

          <ItemsTable mode="status" items={b.items} onDownloadItemXlsx={onDownloadItemXlsx} />
        </>
      )}

      {!b && !state.error && <div style={{ fontSize: 13, color: "#525252" }}>Загрузка статуса…</div>}
    </div>
  );
}

function KV(props: { k: string; v: string }) {
  return (
    <div style={{ minWidth: 160 }}>
      <div style={{ fontSize: 12, color: "#525252", marginBottom: 4 }}>{props.k}</div>
      <div style={{ fontSize: 14, fontWeight: 700 }}>{props.v}</div>
    </div>
  );
}

function humanBatchStatus(s: string): string {
  switch (s) {
    case "RUNNING":
      return "В работе";
    case "DONE":
      return "Готово";
    case "ERROR":
      return "Ошибка";
    default:
      return s;
  }
}

const cardStyle: React.CSSProperties = {
  border: "1px solid #e0e0e0",
  background: "#fff",
  padding: 12,
  borderRadius: 12,
  marginBottom: 12,
};

const warningStyle: React.CSSProperties = {
  border: "1px solid #f1c21b",
  background: "#fff8e1",
  padding: 12,
  borderRadius: 10,
  marginBottom: 12,
};

const errorStyle: React.CSSProperties = {
  border: "1px solid #da1e28",
  background: "#fff1f1",
  padding: 12,
  borderRadius: 10,
  marginBottom: 12,
};

const btnSecondaryStyle: React.CSSProperties = {
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #c6c6c6",
  background: "#fff",
  color: "#161616",
  cursor: "pointer",
  fontWeight: 700,
  fontSize: 13,
};

const btnPrimaryStyle: React.CSSProperties = {
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #0f62fe",
  background: "#0f62fe",
  color: "#fff",
  cursor: "pointer",
  fontWeight: 700,
  fontSize: 13,
};

const btnDisabledStyle: React.CSSProperties = {
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #c6c6c6",
  background: "#f4f4f4",
  color: "#8d8d8d",
  cursor: "not-allowed",
  fontWeight: 700,
  fontSize: 13,
};
