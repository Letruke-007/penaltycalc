import React, { useMemo } from "react";
import { CalendarDays, RefreshCcw } from "lucide-react";
import { FileDrop } from "../components/FileDrop";
import { ItemsTable } from "../components/ItemsTable";
import type { DDMMYYYY } from "../types";
import { useFileUpload } from "../hooks/useFileUpload";
import { useEffect, useRef } from "react";
import { todayDDMMYYYY } from "../utils/date";


export interface UploadBatchProps {
  onBatchCreated: (batchId: string) => void;
}

export function UploadBatch(props: UploadBatchProps) {
  const { onBatchCreated } = props;
  const { state, actions } = useFileUpload();

  const disabled = state.phase === "processing";

  const batchCalcDate = useMemo(() => state.items[0]?.params.calc_date ?? "", [state.items]);
  const batchExcludeZero = useMemo(
    () => state.items[0]?.params.exclude_zero_debt_periods ?? false,
    [state.items],
  );

  const mergeXlsx = state.mergeXlsx;

  const applyToAll = (patch: Partial<{ calc_date: DDMMYYYY; exclude_zero_debt_periods: boolean }>) => {
    for (const it of state.items) {
      actions.updateItemParams(it.clientFileId, patch);
    }
  };

  const lastInspectCountRef = useRef(0);

  useEffect(() => {
    const count = state.items.length;
    if (count === 0) {
      lastInspectCountRef.current = 0;
      return;
    }

    // появились новые файлы → запускаем inspect
    if (count > lastInspectCountRef.current) {
      lastInspectCountRef.current = count;
      actions.runInspect().catch(console.error);
    }
  }, [state.items.length, actions]);

  const showMerge = state.items.length > 1;

  return (
    <div>
      <div style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>Загрузка справок</div>
        <div style={{ fontSize: 13, color: "#525252", lineHeight: 1.35 }}>
          Загрузите PDF-справки. Система извлечёт Наименование и ИНН из текстового слоя (preview), затем вы зададите
          параметры расчёта и запустите обработку. При запуске обработки выполняется полный прогон (PDF → JSON → XLSX).
        </div>
      </div>

      <div style={{ marginBottom: 16 }}>
        <FileDrop
          multiple
          accept="application/pdf"
          disabled={state.phase === "processing"}
          onFiles={(files) => actions.addFiles(files)}
        />
      </div>

      {state.items.length > 0 && (
        <>
          {state.innMismatch.hasMismatch && (
            <div style={warningStyle}>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>Предупреждение</div>
              <div style={{ fontSize: 13 }}>
                Обнаружены разные ИНН в пакете: {state.innMismatch.inns.join(", ")}. Справки загружены по разным
                должникам — проверьте пакет.
              </div>
            </div>
          )}

          {state.globalError && (
            <div style={errorStyle}>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>Ошибка</div>
              <div style={{ fontSize: 13, whiteSpace: "pre-wrap" }}>{state.globalError}</div>
            </div>
          )}

          <div style={batchBarStyle}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
              <label style={labelStyle}>
                <span style={labelTextStyle}>Дата расчёта</span>
                <DateInput
                  value={batchCalcDate}
                  disabled={disabled}
                  onChange={(v) => applyToAll({ calc_date: v as DDMMYYYY })}
                />
              </label>

              <Toggle
                label="Исключить периоды с нулевым долгом"
                checked={batchExcludeZero}
                disabled={disabled}
                onChange={(checked) => applyToAll({ exclude_zero_debt_periods: checked })}
              />

              {showMerge && (
                <Toggle
                  label="Объединить в один XLSX (если должник один)"
                  checked={mergeXlsx}
                  disabled={disabled}
                  onChange={(checked) => actions.setMergeXlsx(checked)}
                />
              )}
            </div>

            <button
              type="button"
              onClick={() => void actions.runInspect()}
              disabled={disabled}
              title="Обновить извлечение (Наименование/ИНН)"
              style={iconBtnStyle}
            >
              <RefreshCcw size={18} />
            </button>
          </div>

          <div style={{ margin: "12px 0 10px", display: "flex", gap: 10, alignItems: "center" }}>
            <button
              type="button"
              onClick={async () => {
                const res = await actions.processBatch();
                onBatchCreated(res.batchId);
              }}
              disabled={!state.canProcess}
              style={btnPrimaryStyle}
              title={!state.canProcess ? "Проверьте обязательные поля и дождитесь завершения извлечения" : ""}
            >
              Запустить обработку (PDF → XLSX)
            </button>

            <button type="button" onClick={actions.clearAll} disabled={disabled} style={btnGhostStyle}>
              Очистить
            </button>

            <div style={{ marginLeft: "auto", fontSize: 13, color: "#525252" }}>
              Статус: <b>{humanPhase(state.phase)}</b>
            </div>
          </div>

          <ItemsTable
            mode="draft"
            items={state.items}
            disabled={disabled}
            onRemove={actions.removeItem}
            onUpdateParams={actions.updateItemParams}
            onReset={actions.resetParams}
            onCopyDown={actions.copyDown}
            onCopyToAll={actions.copyToAll}
            onMoveUp={actions.moveUp}
            onMoveDown={actions.moveDown}
          />
        </>
      )}
    </div>
  );
}

function isDDMMYYYY(v: string): v is DDMMYYYY {
  return /^\d{2}\.\d{2}\.\d{4}$/.test(v);
}


function DateInput(props: {
  value: string;
  disabled?: boolean;
  onChange: (v: DDMMYYYY) => void;
}) {
  const { value, disabled, onChange } = props;

  const [text, setText] = React.useState<string>(value);
  const nativeRef = React.useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    setText(value);
  }, [value]);

  const commitIfValid = (raw: string) => {
    const v = raw.trim();
    if (!v) {
      setText(value);
      return;
    }
    if (!isDDMMYYYY(v)) {
      setText(value);
      return;
    }
    onChange(v as DDMMYYYY);
  };

  const openNativePicker = () => {
    if (disabled) return;
    const el = nativeRef.current;
    if (!el) return;

    // sync hidden native input with current DD.MM.YYYY if valid
    const parsed = parseDDMMYYYY(text);
    if (parsed) {
      el.value = `${parsed.year}-${String(parsed.month).padStart(2, "0")}-${String(parsed.day).padStart(2, "0")}`;
    } else {
      // fallback to today for stable picker behavior
      const t = new Date();
      el.value = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
    }

    const anyEl = el as any;
    if (typeof anyEl.showPicker === "function") {
      anyEl.showPicker();
      return;
    }
    el.focus();
    el.click();
  };

  return (
    <div style={{ position: "relative", display: "inline-flex", alignItems: "center" }}>
      <input
        type="text"
        value={text}
        disabled={disabled}
        placeholder="ДД.ММ.ГГГГ"
        inputMode="numeric"
        onChange={(e) => setText(e.target.value)}
        onBlur={() => commitIfValid(text)}
        style={{
          ...smallInputStyle,
          paddingRight: 40, // место под кнопку внутри поля
        }}
      />

      <button
        type="button"
        onClick={openNativePicker}
        title="Выбрать дату"
        aria-disabled={disabled ? "true" : "false"}
        style={{
          position: "absolute",
          right: 6,
          top: "50%",
          transform: "translateY(-50%)",
          width: 28,
          height: 28,
          borderRadius: 6,
          border: "none",
          background: "transparent",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          opacity: disabled ? 0.45 : 0.7,
          cursor: disabled ? "not-allowed" : "pointer",
        }}
        onMouseEnter={(e) => {
          if (!disabled) e.currentTarget.style.opacity = "1";
        }}
        onMouseLeave={(e) => {
          if (!disabled) e.currentTarget.style.opacity = "0.7";
        }}
      >
        <CalendarDays size={16} />
      </button>


      {/* hidden native date input (calendar source) */}
      <input
        ref={nativeRef}
        type="date"
        tabIndex={-1}
        aria-hidden="true"
        disabled={disabled}
        style={{
          position: "absolute",
          opacity: 0,
          pointerEvents: "none",
          width: 0,
          height: 0,
        }}
        onChange={(e) => {
          const iso = e.target.value; // YYYY-MM-DD
          if (!iso) return;
          const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})$/);
          if (!m) return;
          const yyyy = m[1];
          const mm = m[2];
          const dd = m[3];
          const v = `${dd}.${mm}.${yyyy}` as DDMMYYYY;
          setText(v);
          onChange(v);
        }}
      />
    </div>
  );
}

function parseDDMMYYYY(v: string): { day: number; month: number; year: number } | null {
  const m = v.trim().match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (!m) return null;
  const day = Number(m[1]);
  const month = Number(m[2]);
  const year = Number(m[3]);
  if (!Number.isFinite(day) || !Number.isFinite(month) || !Number.isFinite(year)) return null;
  if (month < 1 || month > 12) return null;
  const dim = new Date(year, month, 0).getDate();
  if (day < 1 || day > dim) return null;
  return { day, month, year };
}


function Toggle(props: {
  label: string;
  checked: boolean;
  disabled?: boolean;
  onChange: (checked: boolean) => void;
}) {
  const { label, checked, disabled, onChange } = props;
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: 10, fontSize: 13, color: "#161616" }}>
      <span>{label}</span>
      <span
        role="switch"
        aria-checked={checked}
        aria-disabled={disabled}
        tabIndex={disabled ? -1 : 0}
        onClick={() => {
          if (disabled) return;
          onChange(!checked);
        }}
        onKeyDown={(e) => {
          if (disabled) return;
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onChange(!checked);
          }
        }}
        style={{
          ...toggleTrackStyle,
          opacity: disabled ? 0.6 : 1,
          background: checked ? "#0f62fe" : "#c6c6c6",
        }}
      >
        <span
          style={{
            ...toggleThumbStyle,
            transform: checked ? "translateX(16px)" : "translateX(0px)",
          }}
        />
      </span>
    </label>
  );
}

function humanPhase(p: string): string {
  switch (p) {
    case "idle":
      return "Ожидание";
    case "inspecting":
      return "Извлечение";
    case "ready":
      return "Готово";
    case "processing":
      return "Обработка";
    case "error":
      return "Ошибка";
    default:
      return p;
  }
}

const warningStyle: React.CSSProperties = {
  border: "1px solid #f1c21b",
  background: "#fff8e1",
  padding: 12,
  borderRadius: 10,
  marginBottom: 12,
};

const dateIconBtnStyle: React.CSSProperties = {
  height: 32,
  width: 32,
  borderRadius: 10,
  border: "1px solid #e5e7eb",
  background: "#fff",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
};

const toggleTrackStyle: React.CSSProperties = {
  width: 40,
  height: 22,
  borderRadius: 999,
  position: "relative",
  border: "1px solid #d1d5db",
  display: "inline-flex",
  alignItems: "center",
  padding: 2,
  cursor: "pointer",
  userSelect: "none",
};

const toggleThumbStyle: React.CSSProperties = {
  width: 18,
  height: 18,
  borderRadius: 999,
  background: "#fff",
  boxShadow: "0 1px 2px rgba(0,0,0,0.15)",
  transition: "transform 120ms ease",
};

const errorStyle: React.CSSProperties = {
  border: "1px solid #da1e28",
  background: "#fff1f1",
  padding: 12,
  borderRadius: 10,
  marginBottom: 12,
};

const batchBarStyle: React.CSSProperties = {
  border: "1px solid #e0e0e0",
  background: "#fff",
  padding: 12,
  borderRadius: 12,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: 10,
};

const labelStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: 10,
};

const labelTextStyle: React.CSSProperties = {
  fontSize: 13,
  color: "#161616",
  fontWeight: 700,
};

const smallInputStyle: React.CSSProperties = {
  padding: "7px 10px",
  borderRadius: 10,
  border: "1px solid #c6c6c6",
  fontSize: 13,
};

const iconBtnStyle: React.CSSProperties = {
  width: 40,
  height: 36,
  borderRadius: 10,
  border: "1px solid #c6c6c6",
  background: "#fff",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
};

const btnPrimaryStyle: React.CSSProperties = {
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #0f62fe",
  background: "#0f62fe",
  color: "#fff",
  cursor: "pointer",
  fontWeight: 700,
  fontSize: 13,
};

const btnGhostStyle: React.CSSProperties = {
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #c6c6c6",
  background: "#fff",
  color: "#161616",
  cursor: "pointer",
  fontWeight: 700,
  fontSize: 13,
};
