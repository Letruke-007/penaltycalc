// frontend/src/App.tsx

import React, { useMemo, useState } from "react";
import { UploadBatch } from "./pages/UploadBatch";
import { BatchStatus } from "./pages/BatchStatus";
import type { BatchId } from "./types";

type Page = "upload" | "status";

export default function App() {
  const [page, setPage] = useState<Page>("upload");
  const [activeBatchId, setActiveBatchId] = useState<BatchId | null>(null);
  const [batchIdInput, setBatchIdInput] = useState<string>("");

  const content = useMemo(() => {
    if (page === "status") {
      if (!activeBatchId) {
        return (
          <div style={{ fontSize: 13, color: "#525252" }}>
            Не выбран batch. Введите Batch ID слева или создайте новый пакет.
          </div>
        );
      }
      return <BatchStatus batchId={activeBatchId} />;
    }

    return (
      <UploadBatch
        onBatchCreated={(batchId) => {
          setActiveBatchId(batchId);
          setBatchIdInput(batchId);
          setPage("status");
        }}
      />
    );
  }, [activeBatchId, page]);

  return (
    <div style={layoutStyle}>
      <aside style={sidebarStyle}>
        <div style={{ fontWeight: 800, fontSize: 16, marginBottom: 14 }}>pdf2xlsx-app</div>

        <nav style={{ display: "grid", gap: 8, marginBottom: 16 }}>
          <SidebarLink
            active={page === "upload"}
            label="Новый пакет"
            onClick={() => setPage("upload")}
          />
          <SidebarLink
            active={page === "status"}
            label="Статус пакета"
            onClick={() => setPage("status")}
          />
        </nav>

        <div style={{ borderTop: "1px solid #e0e0e0", paddingTop: 12 }}>
          <div style={{ fontSize: 12, color: "#525252", marginBottom: 6 }}>Перейти к batch по ID</div>
          <input
            type="text"
            placeholder="Batch ID"
            value={batchIdInput}
            onChange={(e) => setBatchIdInput(e.target.value)}
            style={inputStyle}
          />
          <button
            type="button"
            onClick={() => {
              const id = batchIdInput.trim();
              if (!id) return;
              setActiveBatchId(id);
              setPage("status");
            }}
            style={btnPrimaryStyle}
          >
            Открыть
          </button>
        </div>

        <div style={{ marginTop: "auto", fontSize: 12, color: "#525252" }}>
          MVP frontend (React + TS)
        </div>
      </aside>

      <main style={mainStyle}>{content}</main>
    </div>
  );
}

function SidebarLink(props: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={props.onClick}
      style={{
        width: "100%",
        textAlign: "left",
        padding: "10px 12px",
        borderRadius: 10,
        border: "1px solid " + (props.active ? "#0f62fe" : "#e0e0e0"),
        background: props.active ? "#edf5ff" : "#fff",
        color: "#161616",
        cursor: "pointer",
        fontWeight: 700,
        fontSize: 13,
      }}
    >
      {props.label}
    </button>
  );
}

const layoutStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "260px 1fr",
  minHeight: "100vh",
  background: "#f4f4f4",
};

const sidebarStyle: React.CSSProperties = {
  display: "flex",
  flexDirection: "column",
  gap: 8,
  padding: 16,
  borderRight: "1px solid #e0e0e0",
  background: "#fff",
};

const mainStyle: React.CSSProperties = {
  padding: 18,
  background: "#f4f4f4",
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #c6c6c6",
  marginBottom: 8,
  fontSize: 13,
};

const btnPrimaryStyle: React.CSSProperties = {
  width: "100%",
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #0f62fe",
  background: "#0f62fe",
  color: "#fff",
  cursor: "pointer",
  fontWeight: 800,
  fontSize: 13,
};
