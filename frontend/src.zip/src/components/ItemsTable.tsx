// frontend/src/components/ItemsTable.tsx

import React, { useCallback } from "react";
import type { BatchItem, ConsumerCategory, DDMMYYYY } from "../types";
import type { DraftItem } from "../hooks/useFileUpload";
import { Copy, CopyPlus, ArrowUp, ArrowDown, Trash2, RotateCcw, Download } from "lucide-react";

/* ======================
   Props (discriminated)
====================== */

export interface ItemsTableDraftProps {
  mode: "draft";
  items: DraftItem[];
  disabled?: boolean;

  onRemove: (clientFileId: string) => void;
  onUpdateParams: (
    clientFileId: string,
    patch: Partial<{
      category: ConsumerCategory;
      rate_percent: number;
      overdue_day: number;
      calc_date: DDMMYYYY;
      exclude_zero_debt_periods: boolean;
    }>,
  ) => void;

  onCopyDown?: (clientFileId: string) => void;
  onCopyToAll?: (clientFileId: string) => void;
  onMoveUp?: (clientFileId: string) => void;
  onMoveDown?: (clientFileId: string) => void;
  onReset?: (clientFileId: string) => void;
}

export interface ItemsTableStatusProps {
  mode: "status";
  items: BatchItem[];
  onDownloadItemXlsx?: (itemId: string, filename: string) => Promise<void>;
}

export type ItemsTableProps = ItemsTableDraftProps | ItemsTableStatusProps;

/* ======================
   Root component
====================== */

export function ItemsTable(props: ItemsTableProps) {
  if (props.mode === "status") {
    return <StatusTable items={props.items} onDownloadItemXlsx={props.onDownloadItemXlsx} />;
  }
  return <DraftTable {...props} />;
}

/* ======================
   Draft table
====================== */

function DraftTable(props: ItemsTableDraftProps) {
  const { items } = props;

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={draftTableStyle}>
        <colgroup>
          {/* File / Debtor (takes remaining width) */}
          <col />
          {/* Category (a bit narrower) */}
          <col style={{ width: 260 }} />
          {/* Rate (narrower) */}
          <col style={{ width: 120 }} />
          {/* Overdue day (narrower) */}
          <col style={{ width: 140 }} />
          {/* Actions (fixed, predictable) */}
          <col style={{ width: 260 }} />
        </colgroup>

        <DraftHeader />
        <tbody>
          {items.map((item, idx) => (
            <DraftRow
              key={item.clientFileId}
              item={item}
              index={idx}
              itemsCount={items.length}
              {...props}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
}

function DraftHeader() {
  return (
    <thead>
      <tr>
        <th style={thStyle}>Файл / Должник</th>
        <th style={thStyle}>Категория</th>
        <th style={thStyle}>Учетная ставка, %</th>
        <th style={thStyle}>День начала просрочки</th>
        <th style={{ ...thStyle, textAlign: "right" }}>Действия</th>
      </tr>
    </thead>
  );
}

function DraftRow(
  props: ItemsTableDraftProps & { item: DraftItem; index: number; itemsCount: number },
) {
  const {
    item,
    disabled,
    onRemove,
    onUpdateParams,
    onCopyDown,
    onCopyToAll,
    onMoveUp,
    onMoveDown,
    onReset,
    index,
    itemsCount,
  } = props;

  const patch = useCallback(
    (p: Partial<DraftItem["params"]>) => {
      onUpdateParams(item.clientFileId, p);
    },
    [item.clientFileId, onUpdateParams],
  );

  const DEFAULT_RATE = 9.5;
  const DEFAULT_OVERDUE_DAY = 19;

  // Если params приходят пустыми/частично — сразу дополняем дефолтами (без изменения API).
  // Это предотвращает "съезд" UI на 1 и т.п.
  React.useEffect(() => {
    const rp = item.params.rate_percent;
    const od = item.params.overdue_day;

    // rate_percent: ставим 9.5, если значение отсутствует / невалидно / это "старый дефолт" 9
    const rpInvalid =
      rp == null || !Number.isFinite(rp) || rp <= 0 || rp === 9;
    if (rpInvalid) {
      patch({ rate_percent: DEFAULT_RATE });
    }

    // overdue_day: ставим 19, если значение отсутствует / невалидно / это "старый дефолт" 1
    const odInvalid =
      od == null || !Number.isFinite(od) || od < 1 || od > 31 || od === 1;
    if (odInvalid) {
      patch({ overdue_day: DEFAULT_OVERDUE_DAY });
    }
  }, [item.params.rate_percent, item.params.overdue_day]); // eslint-disable-line react-hooks/exhaustive-deps

  // Keep rate input editable for decimals (e.g. "9.", "9,5") without breaking controlled input.
  const [rateText, setRateText] = React.useState<string>(() =>
    String(item.params.rate_percent ?? DEFAULT_RATE),
  );

  React.useEffect(() => {
    setRateText(String(item.params.rate_percent ?? DEFAULT_RATE));
  }, [item.params.rate_percent]);

  const contractNo = extractContractNo(item.file.name);
  const isFirst = index === 0;
  const isLast = index === itemsCount - 1;

  return (
    <tr>
      <td style={tdStyle}>
        <div style={fileNameLineStyle} title={item.file.name}>
          {item.file.name}
        </div>

        {/* Contract number: derived from file name (no API changes) */}
        {contractNo ? <div style={contractLineStyle}>Договор: {contractNo}</div> : null}

        {/* Debtor MUST be fully visible (no ellipsis) */}
        <div style={debtorLineStyle}>{item.debtor.name ?? "—"}</div>
        <div style={innLineStyle}>ИНН: {item.debtor.inn ?? "—"}</div>
      </td>

      <td style={tdStyle}>
        <select
          value={item.params.category}
          disabled={disabled}
          onChange={(e) => patch({ category: e.target.value as ConsumerCategory })}
          style={selectStyle}
        >
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </td>

      <td style={tdStyle}>
        <input
          type="text"
          inputMode="decimal"
          value={rateText}
          disabled={disabled}
          onChange={(e) => {
            // Allow intermediate states like "9.", "9,5"
            setRateText(e.target.value);
          }}
          onBlur={() => {
            const raw = rateText.trim();
            if (!raw) {
              // Empty input -> revert (rate_percent is required)
              setRateText(String(item.params.rate_percent ?? DEFAULT_RATE));
              return;
            }

            const normalized = raw.replace(",", ".").replace(/\s+/g, "");
            const n = Number(normalized);
            if (!Number.isFinite(n)) {
              // Invalid -> revert
              setRateText(String(item.params.rate_percent ?? DEFAULT_RATE));
              return;
            }

            patch({ rate_percent: n });
          }}
          style={inputStyle}
        />
      </td>

      <td style={tdStyle}>
        <select
          value={item.params.overdue_day ?? DEFAULT_OVERDUE_DAY}
          disabled={disabled}
          onChange={(e) => patch({ overdue_day: Number(e.target.value) })}
          style={selectStyle}
        >
          {OVERDUE_DAYS.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
      </td>

      <td style={{ ...tdStyle, textAlign: "right" }}>
        <div style={actionsRowStyle}>
          {/* Copy */}
          <div style={actionsGroupStyle}>
            <IconBtn
              title="Копировать вниз"
              disabled={disabled || isLast || !onCopyDown}
              onClick={() => onCopyDown?.(item.clientFileId)}
            >
              <Copy size={16} />
            </IconBtn>
            <IconBtn
              title="Копировать всем"
              disabled={disabled || !onCopyToAll}
              onClick={() => onCopyToAll?.(item.clientFileId)}
            >
              <CopyPlus size={16} />
            </IconBtn>
          </div>

          <div style={actionsSeparatorStyle} />

          {/* Order */}
          <div style={actionsGroupStyle}>
            <IconBtn
              title="Вверх"
              disabled={disabled || isFirst || !onMoveUp}
              onClick={() => onMoveUp?.(item.clientFileId)}
            >
              <ArrowUp size={16} />
            </IconBtn>
            <IconBtn
              title="Вниз"
              disabled={disabled || isLast || !onMoveDown}
              onClick={() => onMoveDown?.(item.clientFileId)}
            >
              <ArrowDown size={16} />
            </IconBtn>
          </div>

          <div style={actionsSeparatorStyle} />

          {/* Service */}
          <div style={actionsGroupStyle}>
            <IconBtn
              title="Сброс"
              disabled={disabled || !onReset}
              onClick={() => onReset?.(item.clientFileId)}
            >
              <RotateCcw size={16} />
            </IconBtn>
            <IconBtn
              title="Удалить"
              variant="danger"
              disabled={disabled}
              onClick={() => onRemove(item.clientFileId)}
            >
              <Trash2 size={16} />
            </IconBtn>
          </div>
        </div>
      </td>
    </tr>
  );
}

/* ======================
   Status table
====================== */

 function StatusTable(props: {
   items: BatchItem[];
   onDownloadItemXlsx?: (itemId: string, filename: string) => Promise<void>;
 }) {
   const { items } = props;
   const onDownloadItemXlsx = props.onDownloadItemXlsx;
   const [hoveredKey, setHoveredKey] = React.useState<string | null>(null);

   return (
     <div style={{ overflowX: "auto" }}>
      <table style={tableStyle}>
        <colgroup>
          <col />
          <col style={{ width: 120 }} />
          <col />
          <col style={{ width: 140 }} />
          <col style={{ width: 220 }} />
          <col style={{ width: 180 }} />
          <col style={{ width: 110 }} />
        </colgroup>
         <thead>
           <tr>
            <th style={statusThStyle}>Файл</th>
            <th style={statusThStyle}>Статус</th>
            <th style={statusThStyle}>Наименование</th>
            <th style={statusThStyle}>ИНН</th>
            <th style={statusThStyle}>Параметры</th>
            <th style={statusThStyle}>Предупреждения</th>
            <th style={{ ...statusThStyle, textAlign: "right" }}>XLSX</th>
           </tr>
         </thead>

         <tbody>
           {items.map((item, idx) => {
             const itemId = (item as any).item_id as string | undefined;
             const fileName = ((item as any).file_name ?? "—") as string;
             const statusText = ((item as any).status ?? "—") as string;

             const debtorName = (item as any).debtor?.name ?? "—";
             const debtorInn = (item as any).debtor?.inn ?? "—";

             const params = (item as any).params;
             const paramsText =
               params && params.category && params.rate_percent != null && params.overdue_day != null
                 ? `${params.category}, ${params.rate_percent}%, день ${params.overdue_day}`
                 : "—";

             const warnings = ((item as any).warnings ?? []) as string[];


            // Контракт фронта: наличие готового файла определяем по xlsx_path
            const xlsxPath = (item as any).xlsx_path as string | undefined;
            const xlsxReady = Boolean(xlsxPath);

            const rowKey = (itemId ?? fileName) + "_" + idx;
            const isHovered = hoveredKey === rowKey;

             return (
              <tr
                key={rowKey}
                onMouseEnter={() => setHoveredKey(rowKey)}
                onMouseLeave={() => setHoveredKey(null)}
                style={isHovered ? statusRowHoverStyle : undefined}
              >
                <td style={statusTdStyle}>{fileName}</td>
                <td style={statusTdStyle}>
                  <StatusIndicator status={statusText} />
                </td>
                <td style={statusTdStyle}>{debtorName}</td>
                <td style={statusTdStyle}>{debtorInn}</td>
                <td style={statusTdStyle}>{paramsText}</td>
                <td style={statusTdStyle}>{warnings.length ? warnings.join("; ") : "—"}</td>
                <td style={{ ...statusTdStyle, textAlign: "right" }}>
                  {itemId && xlsxReady && onDownloadItemXlsx ? (
                    <button
                      type="button"
                      onClick={() => void onDownloadItemXlsx(itemId, fileName)}
                      style={xlsxLinkStyle}
                      title="Скачать XLSX"
                    >
                      <Download size={14} />
                      <span style={xlsxLinkTextStyle}>XLSX</span>
                    </button>
                  ) : (
                    <span style={dashMutedStyle}>—</span>
                  )}
                </td>
              </tr>
             );
           })}
         </tbody>
       </table>
     </div>
   );
 }


/* ======================
   Helpers / styles
====================== */

const CATEGORIES: ConsumerCategory[] = [
  "Прочие",
  "ТСЖ, ЖСК, ЖК",
  "УК",
  "Собственники жилых помещений в МКД",
  "Собственники нежилых помещений в МКД",
];

const OVERDUE_DAYS: number[] = Array.from({ length: 31 }, (_, i) => i + 1);

function extractContractNo(fileName: string): string | null {
  // Derive contract number from the file name (no API changes).
  // Examples:
  //  - "01.021576 ТЭ (05.2024-06.2024).pdf" -> "01.021576 ТЭ"
  //  - "01.090077 ТЭ.pdf" -> "01.090077 ТЭ"
  const base = fileName.replace(/\.[^.]+$/, "").trim();
  if (!base) return null;

  const parts = base.split(/\s+/).filter(Boolean);
  if (!parts.length) return null;

  const first = parts[0];
  if (!/\d/.test(first)) return null;

  const second = parts[1];
  if (second && !second.startsWith("(") && /^[\p{L}0-9._+-]+$/u.test(second) && second.length <= 10) {
    return `${first} ${second}`;
  }
  return first;
}

type IconBtnVariant = "default" | "danger";

function IconBtn(props: {
  title: string;
  onClick: () => void;
  children: React.ReactNode;
  disabled?: boolean;
  variant?: IconBtnVariant;
}) {
  const { title, onClick, children, disabled, variant = "default" } = props;
  const [hover, setHover] = React.useState(false);

  const s = getIconBtnStyle({ hover, disabled: !!disabled, variant });

  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      disabled={disabled}
      style={s}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {children}
    </button>
  );
}

function getIconBtnStyle(opts: {
  hover: boolean;
  disabled: boolean;
  variant: IconBtnVariant;
}): React.CSSProperties {
  const { hover, disabled, variant } = opts;

  const base: React.CSSProperties = {
    width: 30,
    height: 30,
    borderRadius: 6,
    border: "1px solid transparent",
    background: "transparent",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    color: variant === "danger" ? "#b91c1c" : "#111827",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.45 : 1,
    transition: "background 120ms ease, border-color 120ms ease",
  };

  if (disabled) return base;

  if (hover) {
    if (variant === "danger") {
      return {
        ...base,
        background: "#fef2f2",
        border: "1px solid #fecaca",
      };
    }
    return {
      ...base,
      background: "#f8fafc",
      border: "1px solid #e5e7eb",
    };
  }

  return base;
}

const draftTableStyle: React.CSSProperties = {
  width: "100%",
  borderCollapse: "collapse",
  minWidth: 940,
  tableLayout: "fixed",
};

const tableStyle: React.CSSProperties = {
  width: "100%",
  borderCollapse: "collapse",
  minWidth: 0,
};

const thStyle: React.CSSProperties = {
  textAlign: "left",
  fontSize: 12,
  color: "#52525b",
  padding: "8px 10px",
  borderBottom: "1px solid #e5e7eb",
  whiteSpace: "nowrap",
};

const tdStyle: React.CSSProperties = {
  padding: "6px 10px",
  borderBottom: "1px solid #f1f5f9",
  verticalAlign: "top",
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  height: 30,
  padding: "0 8px",
  border: "1px solid #e5e7eb",
  borderRadius: 6,
  outline: "none",
};

const selectStyle: React.CSSProperties = {
  width: "100%",
  height: 30,
  padding: "0 8px",
  border: "1px solid #e5e7eb",
  borderRadius: 6,
  outline: "none",
};

const fileNameLineStyle: React.CSSProperties = {
  fontWeight: 600,
  fontSize: 13,
  color: "#111827",
  whiteSpace: "nowrap",
  overflow: "hidden",
  textOverflow: "ellipsis",
};

const contractLineStyle: React.CSSProperties = {
  marginTop: 2,
  fontSize: 11,
  color: "#6b7280",
};

const debtorLineStyle: React.CSSProperties = {
  marginTop: 4,
  fontSize: 12,
  color: "#374151",
  whiteSpace: "normal",
  wordBreak: "break-word",
};

const innLineStyle: React.CSSProperties = {
  marginTop: 2,
  fontSize: 11,
  color: "#9ca3af",
};

const actionsRowStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "flex-end",
  gap: 10,
};

const actionsGroupStyle: React.CSSProperties = {
  display: "inline-flex",
  gap: 6,
};

const actionsSeparatorStyle: React.CSSProperties = {
  width: 1,
  alignSelf: "stretch",
  background: "#e5e7eb",
};

const btnLinkStyle: React.CSSProperties = {
  border: "none",
  background: "transparent",
  color: "#0f62fe",
  cursor: "pointer",
  padding: 0,
};

/* ======================
   Status UI helpers
====================== */

function StatusIndicator(props: { status: string }) {
  const s = String(props.status ?? "").toUpperCase();
  const color = statusDotColor(s);
  return (
    <span style={statusWrapStyle}>
      <span style={{ ...statusDotStyle, background: color }} />
      <span style={statusTextStyle}>{s || "—"}</span>
    </span>
  );
}

function statusDotColor(statusUpper: string): string {
  if (statusUpper === "DONE" || statusUpper === "SUCCESS") return "#16a34a"; // green
  if (statusUpper === "ERROR" || statusUpper === "FAILED") return "#dc2626"; // red
  return "#9ca3af"; // neutral
}

const statusThStyle: React.CSSProperties = {
  textAlign: "left",
  fontSize: 12,
  fontWeight: 500,
  color: "#52525b",
  padding: "8px 10px",
  borderBottom: "1px solid #e5e7eb",
  whiteSpace: "nowrap",
};

const statusTdStyle: React.CSSProperties = {
  padding: "8px 10px",
  borderBottom: "1px solid #f1f5f9",
  verticalAlign: "top",
  fontSize: 13,
  color: "#111827",
};

const statusRowHoverStyle: React.CSSProperties = {
  background: "#f8fafc",
};

const statusWrapStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: 6,
  whiteSpace: "nowrap",
};

const statusDotStyle: React.CSSProperties = {
  width: 8,
  height: 8,
  borderRadius: 999,
  display: "inline-block",
};

const statusTextStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 500,
  color: "#111827",
};

const xlsxLinkStyle: React.CSSProperties = {
  border: "none",
  background: "transparent",
  color: "#2563eb",
  cursor: "pointer",
  padding: 0,
  display: "inline-flex",
  alignItems: "center",
  gap: 6,
};

const xlsxLinkTextStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 600,
  letterSpacing: 0.2,
  textDecoration: "underline",
  textUnderlineOffset: 2,
};

const dashMutedStyle: React.CSSProperties = {
  color: "#9ca3af",
};