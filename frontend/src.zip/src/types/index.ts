// frontend/src/types/index.ts

export * from "./pdf";
