// frontend/src/services/api.ts

import { ApiClient } from "../api/client";

/**
 * MVP assumption:
 * - backend local: http://127.0.0.1:8001
 * - all endpoints under /api
 *
 * If you proxy via Vite later, you can set VITE_API_BASE_URL=""
 * and call "/api/..." directly.
 */
const baseUrl: string = import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:8001";

export const api = new ApiClient({
  baseUrl,
  timeoutMs: 120_000,
});
